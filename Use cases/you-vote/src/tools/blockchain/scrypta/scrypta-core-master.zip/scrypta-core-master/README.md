# Scrypta-Core
JS implementation of main wallet features.
<br>
<br>
<br>
<br>
<a href="http://tiny.cc/devbounty"><img src="https://i.imgur.com/Yf2iz8w.png" title="source: imgur.com" /></a>
